#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
IRIS Staging Server
===================
Modified: 2021-02


"""
from iris_stage.logs.config import config

config()
